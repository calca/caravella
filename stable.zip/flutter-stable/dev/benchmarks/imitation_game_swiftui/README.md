This is the example SwiftUI app used to compare performance to a equivalent Flutter app.
See here for more info: https://github.com/flutter/flutter/issues/154138
