package com.example.a11y_assessments

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
